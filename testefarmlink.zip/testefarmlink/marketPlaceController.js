let MarketPlaceVM = function(){
    console.log('MarketPlace loaded...')
    //let produtos = JSON.parse(localStorage.getItem('produtos'))
    let self = this

    self.produtos = JSON.parse(localStorage.getItem("produtos"))
    

    GetProdutorNome = function(id) {
        let listaprodutores = JSON.parse(localStorage.getItem("produtores"));
        let produtorSelected = listaprodutores[`producer${id}`];
        return produtorSelected["nome"];
    }

    GetProdutorlocalizacao = function(id) {
        let listaprodutores = JSON.parse(localStorage.getItem("produtores"));
        let produtorSelected = listaprodutores[`producer${id}`];
        return produtorSelected["localizacao"];
    }

    GetProdutorRating = function(id) {
        let listaprodutores = JSON.parse(localStorage.getItem("produtores"));
        let produtorSelected = listaprodutores[`producer${id}`];
        return produtorSelected["rating"];
    }

    setCurrentProdutor = function(id) {
        localStorage.setItem("SelectedProducerID", JSON.stringify(id))
    }
    
    
}
    
    
$(document).ready(function () { 
    console.log('Running...')
    console.log(produtos)
    ko.applyBindings(new MarketPlaceVM());
});